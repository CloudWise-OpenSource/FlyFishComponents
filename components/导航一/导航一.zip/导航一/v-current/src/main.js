/**
 * @description 注册title组件到大屏中
 */

import { registerComponent } from 'data-vi/components'

import Component from '../src/Component'

registerComponent('61b08a137f8cf51699105fa3', 'v-current',  Component)
