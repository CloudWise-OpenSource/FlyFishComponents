/**
 * @description 注册组件到大屏中
 */

import { registerComponent } from 'data-vi/components';

import Component from '../src/Component';

registerComponent('62bd5820ea24a70e97a33ea8', 'v-current',  Component);
