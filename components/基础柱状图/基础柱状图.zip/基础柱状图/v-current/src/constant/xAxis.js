/**
 * @description 集中存放部分xAxis的常量以及配置项
 */

/**
 * @description 枚举xAxis位置
 */
export const XAXISPOSITION = {
  bottom: '下方',
  top: '上方',
}