export default {
	data: [{ value: 91, name: '内存使用率' }],
}
