
'use strict';

/**
 * @description 注册627b5d68988a433c0cb98381组件到大屏中
 */

import { registerComponent } from "data-vi/components";

import Component from "./Component";

registerComponent("627b5d68988a433c0cb98381", "v-current", Component);
