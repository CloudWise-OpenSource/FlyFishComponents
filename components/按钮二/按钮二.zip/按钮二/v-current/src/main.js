/**
 * @description 注册组件到大屏中
 */

import { registerComponent } from 'data-vi/components'

import Component from '../src/Component'

registerComponent('61aa27acd39bdf74f6d602d2', 'v-current',  Component)
