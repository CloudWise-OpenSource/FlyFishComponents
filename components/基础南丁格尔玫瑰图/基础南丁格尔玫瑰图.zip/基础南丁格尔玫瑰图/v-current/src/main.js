
'use strict';

/**
 * @description 注册62afd0bb6b1f6420422fa7ad组件到大屏中
 */

import { registerComponent } from "data-vi/components";

import Component from "./Component";

registerComponent('62afd0bb6b1f6420422fa7ad', 'v-current', Component);
