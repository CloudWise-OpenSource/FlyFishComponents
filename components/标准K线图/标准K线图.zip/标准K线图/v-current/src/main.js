
'use strict';

/**
 * @description 注册62a6ac3dd67fbf2034b30684组件到大屏中
 */

import { registerComponent } from "data-vi/components";

import Component from "./Component";

registerComponent("62a6ac3dd67fbf2034b30684", "v-current", Component);
