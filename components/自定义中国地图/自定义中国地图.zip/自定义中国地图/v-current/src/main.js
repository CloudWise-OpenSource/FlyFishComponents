/**
 * @description 注册组件到大屏中
 */

import { registerComponent } from 'data-vi/components';

import Component from './Component';

registerComponent('61efb44befcd191bc1bb4d19', 'v-current',  Component);
