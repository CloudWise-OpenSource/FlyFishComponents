
'use strict';

/**
 * @description 注册62afd877f8ed882065579b40组件到大屏中
 */

import { registerComponent } from "data-vi/components";

import Component from "./Component";

registerComponent('62afd877f8ed882065579b40', 'v-current', Component);
