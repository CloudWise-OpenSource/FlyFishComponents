
/**
 * @description 注册CenterBall组件到大屏中
 */

import { registerComponent } from "data-vi/components";

import Component from "./Component";

registerComponent('62b84d1f26b32a2058aa815c', 'v-current', Component);
