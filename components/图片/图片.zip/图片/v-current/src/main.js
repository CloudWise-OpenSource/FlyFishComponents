
/**
 * @description 注册CommonImage组件到大屏中
 */

import { registerComponent } from "data-vi/components";

import Component from "../src/Component";

registerComponent('61aa27abd39bdf74f6d60142', 'v-current',  Component);
