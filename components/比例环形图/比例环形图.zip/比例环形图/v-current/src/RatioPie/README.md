
# 这是什么
    比例环形图
# 这能做什么
    按比例展示环形图，根据数据部分透明
# 这适用于什么场景
    适用于需要比例环形图的场景
# 版本号
    {
        "echarts": "^5.3.1",
        "echarts-for-react": "^3.0.2"
    }
# 默认数据
```javascript

    [
        {
            value: 300,
            total: 350,
            name: '01'
        },
        {
            value: 150,
            total: 210,
            name: '02'
        },
        {
            value: 80, 
            total: 130,
            name: '03'
        },
        {
            value: 45, 
            total: 75,
            name: '04'
        },
        {
            value: 30, 
            total: 60,
            name: '05'
        }
    ]