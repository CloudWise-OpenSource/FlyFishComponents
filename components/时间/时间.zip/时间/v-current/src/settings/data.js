
import React from "react";

import {
  ComponentDataSetting,
} from "datavi-editor/templates";

export default class DataSetting extends ComponentDataSetting {
  render() {
    return <div></div>;
  }
}
