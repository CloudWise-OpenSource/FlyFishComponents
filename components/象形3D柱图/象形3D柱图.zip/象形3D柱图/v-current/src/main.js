/**
 * @description 注册组件到大屏中
 */

import { registerComponent } from 'data-vi/components';

import Component from '../src/Component';

registerComponent('61cd7a50d1857fd23c9c8bc9', 'v-current',  Component);
