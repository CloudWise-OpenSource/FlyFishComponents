import bar from './assets/bar.svg';
export default {
  data: {
    xAxis: [
      'SSD1004',
      'SAS2007',
      'SSD1007',
      'SSD1008',
      'SSD1009',
      'SSD1010'
    ],
    data: [
      {
        data: [
          {
            value: 557,
          }, {
            value: 658,
          }, {
            value: 705,
          }, {
            value: 708,
          }, {
            value: 710,
          }, {
            value: 720,
          }
        ],
        name: '剩余磁盘'
      },
    ]
  }
}