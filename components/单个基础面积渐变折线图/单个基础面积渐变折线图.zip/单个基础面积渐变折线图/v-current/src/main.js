
'use strict';

/**
 * @description 注册629d997a26b32a2058aa4b86组件到大屏中
 */

import { registerComponent } from "data-vi/components";

import Component from "./Component";

registerComponent("629d997a26b32a2058aa4b86", "v-current", Component);
