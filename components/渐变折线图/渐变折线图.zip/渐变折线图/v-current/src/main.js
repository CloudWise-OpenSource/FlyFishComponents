
'use strict';

/**
 * @description 注册62a6b47855cde8202771f1c5组件到大屏中
 */

import { registerComponent } from "data-vi/components";

import Component from "./Component";

registerComponent("62a6b47855cde8202771f1c5", "v-current", Component);
