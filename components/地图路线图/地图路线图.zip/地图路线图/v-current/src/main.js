
'use strict';

/**
 * @description 注册62a6af1cb80781203cdf73f9组件到大屏中
 */

import { registerComponent } from "data-vi/components";

import Component from "./Component";

registerComponent("62a6af1cb80781203cdf73f9", "v-current", Component);
