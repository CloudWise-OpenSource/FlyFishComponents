
/**
 * @description 注册title组件到大屏中
 */

import { registerComponent } from "data-vi/components";

import Component from "../src/Component";

registerComponent('61b0a25a7f8cf51699105fc7', 'v-current',  Component);
